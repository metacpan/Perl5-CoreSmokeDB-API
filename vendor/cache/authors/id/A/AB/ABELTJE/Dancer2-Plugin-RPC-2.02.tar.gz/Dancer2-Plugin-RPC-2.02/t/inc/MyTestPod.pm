package MyTestPod;

=for restrpc method2 sub2

=cut

sub sub2 { return 42 }
1;
