package MyPoderrorApp;
use warnings;
use strict;

1;

__END__

=head1 DESCRIPTION

Blah..

=for jsonrpc

=head2 explain this method

=for jsonrpc B<method>

=for jsonrpc method code
